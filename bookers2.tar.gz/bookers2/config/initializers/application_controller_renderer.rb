# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '13b93ac1cd9f15307cd7ee7493964223d1261cede726ea14565726454d8eb40efb8749af469aef0a5a4ea2d7bfe01604e7412a8d01b5f4ad1e836d0e6ff85abf'
